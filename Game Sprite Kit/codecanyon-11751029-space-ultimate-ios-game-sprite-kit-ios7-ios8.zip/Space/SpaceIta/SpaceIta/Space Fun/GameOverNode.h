//
//  GameOverNode.h
//  Space Fun
//
//  Created by Itamar Sousa Silva on 09/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameOverNode : SKNode


@end

//
//  GameScene.m
//  Space Fun
//
//  Created by Itamar Sousa Silva on 05/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import "TitleScene.h"
#import "GameScene.h"
#import "Stars.h"
#import "SKEmitterNode+Extensions.h"
#import "GameStartNode.h"
#import "InfoScene.h"
#import "Settings.h"
#import "IAPHelper.h"
#import "GameViewController.h"
@interface TitleScene()

@end

@implementation TitleScene
@synthesize sound;
-(void)didMoveToView:(SKView *)view {
    /* Setup your scene here */
    
    
    
    NSDictionary* def = @{@"interstitial":@YES};
    [[NSUserDefaults standardUserDefaults] registerDefaults:def];
    
    BOOL flag = [[NSUserDefaults standardUserDefaults]boolForKey:@"interstitial"];
    
    self.backgroundColor = [SKColor blackColor];
    
    //Sound initial
    sound = [[Sound alloc] init];
    [[NSUserDefaults standardUserDefaults]registerDefaults:@{@"sound":@"ON"}];
    [sound initSound];
    
  
    [sound stopBackgroundSound];
    if (!BOUGHT) {
        if (flag) {
            [sound startHomeSound];
            [sound stopBackgroundSound];
        }
        else {
            [sound stopHomeSound];
        }
    }
    else{
        [sound startHomeSound];
        [sound stopBackgroundSound];
    }
    
    //Stars
    Stars *starField = [Stars node];
    [self addChild:starField];
    
    //Hero
    SKSpriteNode *hero = [SKSpriteNode spriteNodeWithImageNamed:@"hero"];
    hero.position = CGPointMake(CGRectGetMidX(self.frame),
                                CGRectGetMidY(self.frame));
    [self addChild:hero];
    
    //Engine Fire
    SKEmitterNode *leftEngine = [SKEmitterNode nodeFileWith:@"fireBlue.sks"];
    leftEngine.position = CGPointMake(-35, -49);
    [hero addChild:leftEngine];
    
    SKEmitterNode *rightEngine = [SKEmitterNode nodeFileWith:@"fireBlue.sks"];
    rightEngine.position = CGPointMake(35, -49);
    [hero addChild:rightEngine];
    
    //GameStartNode - Labels
    GameStartNode *gameStartNode = [GameStartNode node];
    gameStartNode.position =  CGPointMake(self.size.width/2, self.size.height-100);
    [self addChild:gameStartNode];
    
    //HighScore
    NSNumberFormatter *scoreFormater = [[NSNumberFormatter alloc]init];
    scoreFormater.numberStyle = NSNumberFormatterDecimalStyle;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults registerDefaults:@{@"highScore":@0}];
    
    NSNumber *score = [[NSUserDefaults standardUserDefaults] valueForKey:@"highScore"];
    NSString *scoreText = [NSString stringWithFormat:@"High Score: %@",[scoreFormater stringFromNumber:score]];
    
    SKLabelNode *labelScore = [SKLabelNode labelNodeWithFontNamed:kFontName];
    labelScore.fontSize = 16;
    labelScore.fontColor = [SKColor whiteColor];
    labelScore.text = scoreText;
    labelScore.position = CGPointMake(self.size.width/2, 100);
    [self addChild:labelScore];
    
    
    //buttons
    SKSpriteNode *faceButton = [SKSpriteNode spriteNodeWithImageNamed:@"faceButton"];
    faceButton.name = @"faceButton";
    faceButton.position = CGPointMake(50, 140);
    [self addChild:faceButton];
    
    SKSpriteNode *twitterButton = [SKSpriteNode spriteNodeWithImageNamed:@"twitterButton"];
    twitterButton.name = @"twitterButton";
    twitterButton.position = CGPointMake(self.size.width-50, 140);
    [self addChild:twitterButton];
    
    SKSpriteNode *infoButton = [SKSpriteNode spriteNodeWithImageNamed:@"infoButton"];
    infoButton.name = @"infoButton";
    infoButton.position = CGPointMake(50, self.size.height-50);
    [self addChild: infoButton];
    
    
    SKSpriteNode *gameCenter = [SKSpriteNode spriteNodeWithImageNamed:@"gamecenter"];
    gameCenter.name = @"gamecenter";
    gameCenter.position = CGPointMake(40, self.size.height/2+100);
    [self addChild:gameCenter];
    
    
    
    if (!BOUGHT) {
        self.adsButton = [SKSpriteNode spriteNodeWithImageNamed:@"adsButton"];
        self.adsButton.name = @"adsButton";
        self.adsButton.position = CGPointMake(self.size.width-40, self.size.height/2+100);
        [self addChild: self.adsButton];
    }
    

    self.soundButton = [[SKSpriteNode alloc]init];
    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"sound"]isEqualToString:@"ON"]){
        SKTexture *texture = [SKTexture textureWithImageNamed:@"soundButton"];
        self.soundButton = [SKSpriteNode spriteNodeWithTexture:texture];
            }
    else{
        SKTexture *texture = [SKTexture textureWithImageNamed:@"soundOff"];
        self.soundButton = [SKSpriteNode spriteNodeWithTexture:texture];
        
    }

    self.soundButton.name = @"soundButton";
    self.soundButton.position = CGPointMake(self.size.width-50,self.size.height-50);
    [self addChild:self.soundButton];
    
   
}


-(void)comprado{
    self.adsButton.alpha = 0.2;
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    
    for (UITouch *touch in touches)
    {
        
        CGPoint location = [touch locationInNode:self];
        if ( [[self nodeAtPoint:location].name isEqualToString:@"faceButton"] )
        {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"shareFacebook" object:nil];
        }
        
        if ( [[self nodeAtPoint:location].name isEqualToString:@"twitterButton"] )
        {
            [[NSNotificationCenter defaultCenter]postNotificationName:@"shareTwitter" object:nil];
            
        }
        
        if ( [[self nodeAtPoint:location].name isEqualToString:@"infoButton"] )
        {
            InfoScene *infoScene = [InfoScene sceneWithSize:self.frame.size];
            SKTransition *transition = [SKTransition doorsOpenHorizontalWithDuration:1.0];
            [self.view presentScene:infoScene transition:transition];
           
        }
        
        if ( [[self nodeAtPoint:location].name isEqualToString:@"adsButton"] )
        {
            if (BOUGHT) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Ops!" message:@"You already purchased this item" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
                [alert show];
              
            }
            else{
            [[NSNotificationCenter defaultCenter]postNotificationName:@"adsButton" object:nil];
            }
        }
        
        if ( [[self nodeAtPoint:location].name isEqualToString:@"soundButton"] )
        {
            if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"sound"]isEqualToString:@"ON"]){
                [sound stopHomeSound];
                self.soundButton.texture = [SKTexture textureWithImageNamed:@"soundOff"];
                 [[NSUserDefaults standardUserDefaults]setObject:@"OFF" forKey:@"sound"];
                //soundOff
            }
            else{
                 [[NSUserDefaults standardUserDefaults]setObject:@"ON" forKey:@"sound"];
                self.soundButton.texture = [SKTexture textureWithImageNamed:@"soundButton"];
                [sound startHomeSound];
            }
           
        }
        
        if ( [[self nodeAtPoint:location].name isEqualToString:@"gamecenter"] )
        {
            [[NSNotificationCenter defaultCenter]postNotificationName:@"showLeaderboard" object:nil];
            
        }
        
        if ([self nodeAtPoint:location].name == NULL){
            GameScene *gameScene = [GameScene sceneWithSize:self.frame.size];
            SKTransition *transition = [SKTransition fadeWithDuration:1.0];
            [self.view presentScene:gameScene transition:transition];
            
        }

    }

}


-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
   
    
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
   
      [self.adsButton removeFromParent];
}

@end

//
//  InfoScence.h
//  Space Fun
//
//  Created by Itamar Sousa Silva on 13/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface InfoScene : SKScene

@end

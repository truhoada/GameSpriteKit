//
//  GameScene.h
//  Space Fun
//
//  Created by Itamar Sousa Silva on 05/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
#import "Sound.h"

@interface GameScene : SKScene{
    Sound *sound;
}
@property (nonatomic) BOOL stop;
@property (nonatomic) BOOL isGamePaused;

-(void)pauseView;
-(void)playFromPause;

@end

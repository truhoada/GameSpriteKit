//
//  GameViewController.m
//  Space Fun
//
//  Created by Itamar Sousa Silva on 05/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import "GameViewController.h"
#import "TitleScene.h"
#define IS_IPAD UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad

@implementation SKScene (Unarchive)

static RevMobBanner *sRevMobBannerView;
static bool sRevmobBannerClosed = false;

+ (instancetype)unarchiveFromFile:(NSString *)file {
    /* Retrieve scene file path from the application bundle */
    NSString *nodePath = [[NSBundle mainBundle] pathForResource:file ofType:@"sks"];
    /* Unarchive the file to an SKScene object */
    NSData *data = [NSData dataWithContentsOfFile:nodePath
                                          options:NSDataReadingMappedIfSafe
                                            error:nil];
    NSKeyedUnarchiver *arch = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    [arch setClass:self forClassName:@"SKScene"];
    SKScene *scene = [arch decodeObjectForKey:NSKeyedArchiveRootObjectKey];
    [arch finishDecoding];
    
    return scene;
}

@end

@implementation GameViewController


-(void)viewWillLayoutSubviews
{
    
 
    SKView * skView = (SKView *)self.view;

    // Create and configure the scene.
    TitleScene * scene = [TitleScene sceneWithSize:skView.bounds.size];
    scene.scaleMode = SKSceneScaleModeAspectFill;

    
    // Present the scene.
    [skView presentScene:scene];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
 
    sRevmobBannerClosed = false;
    [self authenticateLocalPlayer];
  
    sound = [[Sound alloc] init];
    [sound initSound];
  
    //AdMob view setting
    
    if (!BOUGHT) {
        if (GOOGLE_ADS) {
            
        
        CGPoint origin = CGPointMake(0.0,
                                     self.view.frame.size.height -
                                     CGSizeFromGADAdSize(
                                                         kGADAdSizeSmartBannerPortrait).height);
        bannerView = [[GADBannerView alloc]
                      initWithAdSize:kGADAdSizeSmartBannerPortrait
                      origin:origin];
        bannerView.adUnitID = AdMobID;
        bannerView.rootViewController = self;
        [self.view addSubview:bannerView];
        [bannerView loadRequest:[GADRequest request]];
        }
        
        if (REVMOD_ADS) {
            [RevMobAds startSessionWithAppID:RevMobID andDelegate:self];
        
            [RevMobAds startSessionWithAppID:RevMobID];
            [self loadRevmob];
        }
        
        [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"interstitial"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startGame) name:@"startGame" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(gameOver) name:@"gameOver" object:nil];
        bannerView.hidden = NO;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(purchased) name:IAPHelperProductPurchasedNotification object:nil];
   
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shareFacebook) name:@"shareFacebook" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shareTwitter) name:@"shareTwitter" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rateApp) name:@"rate" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(contact) name:@"contact" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(buyInapp) name:@"adsButton" object:nil];
    
    // Configure the view.
    SKView * skView = (SKView *)self.view;
    skView.showsFPS = NO;
    skView.showsNodeCount = NO;
    /* Sprite Kit applies additional optimizations to improve rendering performance */
    skView.ignoresSiblingOrder = YES;
    
    
    
    // Create and configure the scene.
    TitleScene *scene = [TitleScene unarchiveFromFile:@"GameScene"];
    scene.scaleMode = SKSceneScaleModeAspectFill;
     [self authenticateLocalPlayer];

    // Present the scene.
    [skView presentScene:scene];
    //Game center
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveScore) name:@"saveScore" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showLeaderboard) name:@"showLeaderboard" object:nil];
    
    [self authenticateLocalPlayer];
}

- (BOOL)shouldAutorotate
{
    return YES;
}


- (NSUInteger)supportedInterfaceOrientations
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return UIInterfaceOrientationMaskAllButUpsideDown;
    } else {
        return UIInterfaceOrientationMaskAll;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}


#pragma mark Share

-(void)shareFacebook{
    
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
        
        SLComposeViewController *escrevedor = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        NSNumberFormatter *scoreFormater = [[NSNumberFormatter alloc]init];
        scoreFormater.numberStyle = NSNumberFormatterDecimalStyle;

        NSNumber *score = [[NSUserDefaults standardUserDefaults] valueForKey:@"highScore"];
        NSString *scoreText = [NSString stringWithFormat:@"High Score: %@",[scoreFormater stringFromNumber:score]];
        [escrevedor setInitialText:[NSString stringWithFormat:kTextShareMessage,scoreText]];
       [escrevedor addImage:[UIImage imageNamed:@"iconShare"]];
        
        
        [self presentViewController:escrevedor animated:YES completion:nil];
    }

    
}

-(void)shareTwitter{
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter]) {
        
        SLComposeViewController *escrevedor = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
        NSNumberFormatter *scoreFormater = [[NSNumberFormatter alloc]init];
        scoreFormater.numberStyle = NSNumberFormatterDecimalStyle;
        NSNumber *score = [[NSUserDefaults standardUserDefaults] valueForKey:@"highScore"];
        NSString *scoreText = [NSString stringWithFormat:@"High Score: %@",[scoreFormater stringFromNumber:score]];
        [escrevedor setInitialText:[NSString stringWithFormat:kTextShareMessage,scoreText]];
        [escrevedor addImage:[UIImage imageNamed:@"iconShare"]];

        
        
        [self presentViewController:escrevedor animated:YES completion:nil];
    }
}

-(void)startGame{
    
    if (!BOUGHT) {
    [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"interstitial"];
    [[NSUserDefaults standardUserDefaults]synchronize];
        if (GOOGLE_ADS) {
          [self createAndLoadInterstitial];
        }
  
    }
}

-(void)gameOver{
    
    if (GOOGLE_ADS) {
        if (self.interstitial.isReady) {
            [self.interstitial presentFromRootViewController:self];
        }
    }
    if (REVMOD_ADS) {
        [self showFullscreenWithDelegate];
    }

}

-(void)loadRevmob{
    CGSize gBannerViewFrameSize = (IS_IPAD?CGSizeMake(768.000000,90.000000):CGSizeMake(320, 50));
}
#pragma mark RevMob banner
-(void)createRevMobBanner {
    if (sRevMobBannerView != nil) {
        return;
    }
    sRevmobBannerClosed = false;
    sRevMobBannerView = [[RevMobAds session]banner];
    sRevMobBannerView.delegate = self;
}
+(void)showRevMobBanner:(bool)closed{
    sRevmobBannerClosed = closed;
    [sRevMobBannerView showAd];
}
+(void)hideRevMobBanner:(bool)closed{
    sRevmobBannerClosed = closed;
    [sRevMobBannerView hideAd];
}
-(void)revmobSessionIsStarted{
    [self createRevMobBanner];
    [GameViewController showRevMobBanner:false];
}
-(void)revmobAdDidReceive{
    if (!sRevmobBannerClosed) {
        [GameViewController showRevMobBanner:false];
    }
}
-(void)revmobAdDidFailWithError:(NSError *)error{
    if (!sRevmobBannerClosed) {
        [GameViewController hideRevMobBanner:false];
    }
}

#pragma mark Fullscreen

- (void)showFullscreenWithDelegate {
    RevMobFullscreen *fs = [[RevMobAds session] fullscreen];
    fs.delegate = self;
    [fs showAd];
}

- (void)showFullscreenWithSpecificOrientations {
    RevMobFullscreen *fs = [[RevMobAds session] fullscreen];
    fs.supportedInterfaceOrientations = @[@(UIInterfaceOrientationLandscapeRight), @(UIInterfaceOrientationLandscapeLeft)];
    
    [fs loadWithSuccessHandler:^(RevMobFullscreen *fs) {
        [fs showAd];
        [self revmobAdDidReceive];
        [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"interstitial"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    } andLoadFailHandler:^(RevMobFullscreen *fs, NSError *error) {
        [self revmobAdDidFailWithError:error];
        [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"interstitial"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    } onClickHandler:^{
        [self revmobUserClickedInTheAd];
    } onCloseHandler:^{
        [self revmobUserClosedTheAd];
        [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"interstitial"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }];
}




- (void)createAndLoadInterstitial {
    self.interstitial = [[GADInterstitial alloc] init];
    self.interstitial.adUnitID = AdMobIN;
    self.interstitial.delegate = self;
    [sound stopHomeSound];
    [sound stopBackgroundSound];
    
    GADRequest *request = [GADRequest request];

    [self.interstitial loadRequest:request];
}

#pragma mark Rate Us

- (void)rateApp{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Like this app?" message:@"Rate this app!" delegate:self cancelButtonTitle:@"No, thanks" otherButtonTitles:@"Yes", nil];
    alert.tag = 0;
    [alert show];
}

-(void)buyInapp{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Remove Ads" message:nil delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Buy",@"Restore", nil];
    alert.tag = 1;
    [alert show];

}
-(void)purchased{
    bannerView.hidden = YES;
    [sRevMobBannerView hideAd];
    
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    switch (alertView.tag) {
        case 0:
            if (buttonIndex == 0) {
                //Cancel button
            }
            else if (buttonIndex == 1) {
                //Yes button
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:RATEUS_LINK]];
            }
            break;
        case 1:
            if (buttonIndex == 0) {
                //Cancel button
            }
            else if (buttonIndex == 1) {
                [SVProgressHUD showWithStatus:@"Loading..." maskType:SVProgressHUDMaskTypeClear];
                
                [[RageIAPHelper sharedInstance] requestProductsWithCompletionHandler:^(BOOL success, NSArray *products) {
                    [SVProgressHUD dismiss];
                    
                    if (success) {
                        SKProduct *product = [products objectAtIndex:0];
                        
                        NSLog(@"Buying %@...", product.productIdentifier);
                        [[RageIAPHelper sharedInstance] buyProduct:product];
                        
                    }
                }];

            }
            else{
                [[RageIAPHelper sharedInstance] restoreCompletedTransactions];
                
            }
            break;

            
        default:
            break;
    }
  }

-(void)contact{
    if ([MFMailComposeViewController canSendMail]) {
        // Criação do objeto responsável pela tela de envio de email
        MFMailComposeViewController *emailCompose = [[MFMailComposeViewController alloc] init];
        
        // Métodos que preenchem os campos
        // Método que define o assunto do email
        [emailCompose setSubject:[NSString stringWithFormat:@"About %@", kTitleApp]];
        
        // Método que define o corpo do email
        [emailCompose setMessageBody:kTextEmailBody isHTML:NO];
        [emailCompose setToRecipients:@[kEmailContact]];
        
        // Ligar o delegate
        emailCompose.mailComposeDelegate = self;
        
        // Apresentar a janela
        [self presentViewController:emailCompose animated:YES completion:nil];
    }

}
#pragma mark - MFMailComposeViewControllerDelegate

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result) {
        case MFMailComposeResultSent:
            break;
        case MFMailComposeResultFailed:
            [self alertShareFailed];
            break;
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            break;
            
        default:
            break;
    }
    [controller dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark GADInterstitialDelegate implementation
-(void)interstitialWillPresentScreen:(GADInterstitial *)ad{
    
    NSLog(@"interstitialWillPresentScreen");
    [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"interstitial"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
}
-(void)interstitialDidReceiveAd:(GADInterstitial *)ad{
    NSLog(@"interstitialDidReceiveAd");
    
}

- (void)interstitial:(GADInterstitial *)interstitial
didFailToReceiveAdWithError:(GADRequestError *)error {
    NSLog(@"epaaaaaa interstitialDidFailToReceiveAdWithError: %@", [error localizedDescription]);
    [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"interstitial"];
    [[NSUserDefaults standardUserDefaults]synchronize];
}

- (void)interstitialDidDismissScreen:(GADInterstitial *)interstitial {
    NSLog(@"interstitialDidDismissScreen");
    [self startGame];
    
    [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"interstitial"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
}

-(void)alertShareFailed{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:kTextErrorShare delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    [alert show];
}
#pragma mark Game Center



- (void)authenticateLocalPlayer {
    GKLocalPlayer *localPlayer = [GKLocalPlayer localPlayer];
    localPlayer.authenticateHandler = ^(UIViewController *viewController, NSError *error){
        if (viewController != nil) {
            [self presentViewController:viewController animated:YES completion:nil];
        }
        else{
            if ([GKLocalPlayer localPlayer].authenticated) {
                _gameCenterEnabled = YES;
                
                // Get the default leaderboard identifier.
                [[GKLocalPlayer localPlayer] loadDefaultLeaderboardIdentifierWithCompletionHandler:^(NSString *leaderboardIdentifier, NSError *error) {
                    
                    if (error != nil) {
                        NSLog(@"opaaaaaaa%@", [error localizedDescription]);
                    }
                    else{
                        _leaderboardIdentifier = leaderboardIdentifier;
                    }
                }];
            }
            
            else{
                _gameCenterEnabled = NO;
            }
        }
    };
}

- (void)saveScore {
       if ([GKLocalPlayer localPlayer].authenticated) {
    GKScore *score = [[GKScore alloc] initWithLeaderboardIdentifier:_leaderboardIdentifier];
    NSInteger teste = [[[NSUserDefaults standardUserDefaults] valueForKey:@"highScore"]integerValue];
    score.value = teste;
    
    [GKScore reportScores:@[score] withCompletionHandler:^(NSError *error) {
        if (error != nil) {
            NSLog(@"%@", [error localizedDescription]);
        }
    }];
       }
}

- (void)showLeaderboard {
    [self authenticateLocalPlayer];
    GKGameCenterViewController *gcViewController = [[GKGameCenterViewController alloc] init];
    
    gcViewController.gameCenterDelegate = self;
    
    gcViewController.viewState = GKGameCenterViewControllerStateLeaderboards;
    gcViewController.leaderboardIdentifier = _leaderboardIdentifier;
    
    [self presentViewController:gcViewController animated:YES completion:nil];
}

- (void)gameCenterViewControllerDidFinish:(GKGameCenterViewController *)gameCenterViewController {
    [gameCenterViewController dismissViewControllerAnimated:YES completion:nil];
}

@end

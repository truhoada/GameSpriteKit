//
//  GameScene.m
//  Space Fun
//
//  Created by Itamar Sousa Silva on 05/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import "GameScene.h"
#import "Stars.h"
#import "SKEmitterNode+Extensions.h"
#import "HUDNode.h"
#import "TitleScene.h"
#import "GameOverNode.h"
#import "Settings.h"

#define IS_IPAD UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad
@interface GameScene ()

@property (nonatomic, weak) UITouch *heroTouch;
@property (nonatomic) NSTimeInterval lastUpdateTime;
@property (nonatomic) NSTimeInterval lastFireTime;
@property (nonatomic) CGFloat fireRate;
@property (nonatomic) BOOL doubleFire;
@property (nonatomic) BOOL shootRocket;
@property (nonatomic) BOOL allowedToTouch;


@property (nonatomic, strong) SKEmitterNode *enemyExplosionTemplate;
@property (nonatomic, strong) SKEmitterNode *heroExplosionTemplate;
@property (nonatomic, strong) SKEmitterNode *asteroidExplosionTemplate;

@property (nonatomic, strong) SKAction *shootSound;
@property (nonatomic, strong) SKAction *enemyExplodeSound;
@property (nonatomic, strong) SKAction *heroExplodeSound;


@property (nonatomic) BOOL gameOver;
@property (nonatomic) NSInteger countShoot;
@property (nonatomic) NSInteger life;

/// The countdown timer.
@property(nonatomic, strong) NSTimer *timer;

/// The game counter.
@property(nonatomic, assign) NSInteger counter;


@end

@implementation GameScene


-(void)didMoveToView:(SKView *)view {
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(pauseView)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    
    
       self.backgroundColor = [SKColor blackColor];
   

    
    [[NSNotificationCenter defaultCenter]postNotificationName:@"startGame" object:self];
        //Sound initial
        sound = [[Sound alloc] init];
        [sound initSound];
        [sound playBackgroundSound];
    
        //Background Stars
        Stars *starField = [Stars node];
        [self addChild:starField];
        
        //Hero
        SKSpriteNode *hero = [SKSpriteNode spriteNodeWithImageNamed:@"heroPlayer"];
        hero.position = CGPointMake(CGRectGetMidX(self.frame),
                                    CGRectGetMidY(self.frame));
    
    if (IS_IPAD) {
        hero.size = CGSizeMake(90, 100);
    }
    else{
        hero.size = CGSizeMake(45, 50);
    }
        hero.name = @"hero";
    
        [self addChild:hero];

    //Engine Fire
    SKEmitterNode *leftEngine = [SKEmitterNode nodeFileWith:@"fireSmallBlue.sks"];
    if (IS_IPAD) {
        leftEngine.position = CGPointMake(-34, -44);
    }
    else{
        leftEngine.position = CGPointMake(-17, -22);
    }
 
    [hero addChild:leftEngine];
    
    SKEmitterNode *rightEngine = [SKEmitterNode nodeFileWith:@"fireSmallBlue.sks"];
    if (IS_IPAD) {
        rightEngine.position = CGPointMake(34, -44);
    }
    else{
        rightEngine.position = CGPointMake(17, -22);
    }
    
    [hero addChild:rightEngine];
    
    SKSpriteNode *pauseButton = [SKSpriteNode spriteNodeWithImageNamed:@"pauseButton"];
    pauseButton.position = CGPointMake(self.scene.size.width-50, self.scene.size.height-50);
    [self addChild:pauseButton];
    pauseButton.name = @"pauseButton";

    
    //set fire rate
    self.fireRate = 0.5;
    self.doubleFire = NO;
    self.shootRocket = NO;
    
    [self checkForColissions];
    
    // Explosions Template
    self.enemyExplosionTemplate = [SKEmitterNode nodeFileWith:@"enemyExplosion.sks"];
    self.heroExplosionTemplate = [SKEmitterNode nodeFileWith:@"heroExplosion.sks"];
    self.asteroidExplosionTemplate = [SKEmitterNode nodeFileWith:@"asteroidExplosion.sks"];
    
    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"sound"]isEqualToString:@"ON"]){
    // Initalizie sounds
    self.shootSound = [SKAction playSoundFileNamed:kShootSound waitForCompletion:NO];
    self.enemyExplodeSound = [SKAction playSoundFileNamed:kEnemyExplosionSound waitForCompletion:NO];
    self.heroExplodeSound = [SKAction playSoundFileNamed:kHeroExplosionSound waitForCompletion:NO];
    }
    
    //HUDNode
    HUDNode *hudNode = [HUDNode node];
    hudNode.name = @"hudNode";
    hudNode.zPosition = 150;
    hudNode.position = CGPointMake(self.size.width/2, self.size.height/2);
    [self addChild:hudNode];
    
    [hudNode layoutControls];
    [hudNode startGame];

    self.gameOver = NO;
    self.countShoot = 0;
    self.allowedToTouch = YES;
    
    self.life = 100;
    
    
  
   
}



-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{

    self.heroTouch =  [touches anyObject];
    
    
    for (UITouch *touch in touches)
    {
        
        CGPoint location = [touch locationInNode:self];
        if ( [[self nodeAtPoint:location].name isEqualToString:@"pauseButton"] )
        {
            NSLog(@"pause butten has been pressed");
           
            [self pauseView];
            
        }
        
        if ( [[self nodeAtPoint:location].name isEqualToString:@"playButton"] )
        {
            NSLog(@"pPLAY butten has been pressed");
            
            [self playFromPause];
            
        }
        
        if ( [[self nodeAtPoint:location].name isEqualToString:@"homeButton"] )
        {
            
            [self showMenu];
            
        }
        
        if (![[self nodeAtPoint:location].name isEqualToString:@"pauseButton"] ){
            if (self.gameOver) {
                for (SKNode *node in [self children]) {
                    [node removeFromParent];
                }
                [self showMenu];
            }

        }
            }
    
    
}

-(void)checkForColissions{
    
    SKNode *hero = [self childNodeWithName:@"hero"];
    
    [self enumerateChildNodesWithName:@"power" usingBlock:^(SKNode *power, BOOL *stop) {
        
        if ([hero intersectsNode:power]) {
            HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
            [hudNode showPowerTime:5];
            
            [power removeFromParent];
            self.fireRate = 0.1;
            
            
            SKAction *powerDown = [SKAction runBlock:^{
                self.fireRate = 0.5;
          
            }];
            
            SKAction *wait = [SKAction waitForDuration:5];
            SKAction *waitAndPowerDow = [SKAction sequence:@[wait, powerDown]];
            [hero removeActionForKey:@"waitAndPowerDow"];
            [hero runAction:waitAndPowerDow withKey:@"waitAndPowerDow"];
        }
        
    }];
    
    [self enumerateChildNodesWithName:@"doublefire" usingBlock:^(SKNode *doublefire, BOOL *stop) {
        
        if ([hero intersectsNode:doublefire]) {
            HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
            [hudNode showDoubleFireTime:7];
            
            [doublefire removeFromParent];
            self.doubleFire = YES;
            
            SKAction *removeDoublepower = [SKAction runBlock:^{
                self.doubleFire = NO;
            }];
            
            SKAction *wait = [SKAction waitForDuration:7];
            SKAction *waitAndDoubleFire = [SKAction sequence:@[wait, removeDoublepower]];
            [hero removeActionForKey:@"waitAndDoubleFire"];
            [hero runAction:waitAndDoubleFire withKey:@"waitAndDoubleFire"];
        }
        
    }];
    
    [self enumerateChildNodesWithName:@"rocketPower" usingBlock:^(SKNode *rocketPower, BOOL *stop) {
        
        if ([hero intersectsNode:rocketPower]) {
            HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
            // doubleFire and shootRocket is equal
            [hudNode showRocketPowerTime:7];
            [rocketPower removeFromParent];
            self.shootRocket = YES;
            
            SKAction *removeRocketPower = [SKAction runBlock:^{
                self.shootRocket = NO;
            }];
            
            SKAction *waitRP = [SKAction waitForDuration:7];
            SKAction *waitAndRocketPower = [SKAction sequence:@[waitRP, removeRocketPower]];
            [hero removeActionForKey:@"waitAndRocketPower"];
            [hero runAction:waitAndRocketPower withKey:@"waitAndRocketPower"];
        }
        
    }];
    
    
    [self enumerateChildNodesWithName:@"enemy" usingBlock:^(SKNode *enemy, BOOL *stop) {
        if ([hero intersectsNode:enemy]) {
    
            SKEmitterNode *explosion = [self.enemyExplosionTemplate copy];
            hero.position = hero.position;
            [explosion dieInDuration:0.1];
            [hero addChild:explosion];
            
       
            
            HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
            self.life = self.life - 0.5;
            [hudNode updateLife:self.life];
            [self runAction:self.enemyExplodeSound];
            if (self.life == 0) {
                self.heroTouch = nil;
                [hero removeFromParent];
                [enemy removeFromParent];
                
                SKEmitterNode *explosion = [self.heroExplosionTemplate copy];
                explosion.position =  hero.position;
                explosion.position =  enemy.position;
                [explosion dieInDuration:0.3];
                [self addChild:explosion];
                 [self endGame];
                
            }
           
        }
        
        [self enumerateChildNodesWithName:@"fire" usingBlock:^(SKNode *fire, BOOL *stop) {
            if ([fire intersectsNode:enemy]) {
                [fire removeFromParent];
                [enemy removeFromParent];
                
                [self runAction:self.enemyExplodeSound];
                
                SKEmitterNode *explosion = [self.enemyExplosionTemplate copy];
                explosion.position = enemy.position;
                [explosion dieInDuration:0.1];
                [self addChild:explosion];
                
                HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
                NSInteger score = 10 * hudNode.elapsedTime;
                [hudNode addPoints:score];
                
                *stop =  YES;
            }
            
            
        }];
        
        [self enumerateChildNodesWithName:@"shootRocket" usingBlock:^(SKNode *shootRocket, BOOL *stop)
         {
             if ([shootRocket intersectsNode:enemy]) {
                 [shootRocket removeFromParent];
                 [enemy removeFromParent];
                 
                 [self runAction:self.enemyExplodeSound];
                 
                 SKEmitterNode *explosion = [self.enemyExplosionTemplate copy];
                 explosion.position = enemy.position;
                 [explosion dieInDuration:0.1];
                 [self addChild:explosion];
                 
                 HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
                 NSInteger score = 10 * hudNode.elapsedTime;
                 [hudNode addPoints:score];
                 
                 *stop =  YES;
             }
             
         }];
        
        
    }];
    
    [self enumerateChildNodesWithName:@"asteroid" usingBlock:^(SKNode *asteroid, BOOL *stop) {
        if ([hero intersectsNode:asteroid]) {
            
                self.heroTouch = nil;
                [hero removeFromParent];
                [asteroid removeFromParent];
            
                HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
                self.life = 0;
                [hudNode updateLife:self.life];
            
                SKEmitterNode *explosion = [self.heroExplosionTemplate copy];
                explosion.position =  hero.position;
                [explosion dieInDuration:0.3];
                [self addChild:explosion];
                [self endGame];
            
            [self runAction:self.heroExplodeSound];
        }
        
        [self enumerateChildNodesWithName:@"fire" usingBlock:^(SKNode *fire, BOOL *stop) {
            if ([fire intersectsNode:asteroid]) {
                self.countShoot += 1;
                
                SKEmitterNode *explosion = [self.enemyExplosionTemplate copy];
                explosion.position = asteroid.position;
                [explosion dieInDuration:0.1];
                [self addChild:explosion];
                
                if (self.countShoot == 15) {
                    self.countShoot = 0;
                    [fire removeFromParent];
                    [asteroid removeFromParent];
                    
                    [self runAction:self.enemyExplodeSound];
                    
                    SKEmitterNode *explosion = [self.enemyExplosionTemplate copy];
                    explosion.position = asteroid.position;
                    [explosion dieInDuration:0.1];
                    [self addChild:explosion];
                    
                    HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
                    NSInteger score = 10 * hudNode.elapsedTime;
                    [hudNode addPoints:score];
                    
                    *stop =  YES;
                }
             
            }
            
            [self enumerateChildNodesWithName:@"shootRocket" usingBlock:^(SKNode *shootRocket, BOOL *stop)
             {
                if ([shootRocket intersectsNode:asteroid]) {
                    [shootRocket removeFromParent];
                    [asteroid removeFromParent];
                    
                    [self runAction:self.enemyExplodeSound];
                    
                    SKEmitterNode *explosion = [self.enemyExplosionTemplate copy];
                    explosion.position = asteroid.position;
                    [explosion dieInDuration:0.1];
                    [self addChild:explosion];
                    
                    HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
                    NSInteger score = 10 * hudNode.elapsedTime;
                    [hudNode addPoints:score];
                    
                    *stop =  YES;
                }
                
                
            }];
            
            
        }];
        
    }];

}

-(void)update:(NSTimeInterval)currentTime{
    
    
    
    if (self.lastUpdateTime == 0) {
        self.lastUpdateTime = currentTime;
    }
    
    NSTimeInterval delta =  currentTime - self.lastUpdateTime;
    
    if (self.heroTouch) {
        CGPoint touchLocation = [self.heroTouch locationInNode:self];
        touchLocation.y +=70;
        [self moveHero:touchLocation byTimeDelta:delta];
        
        if (currentTime - self.lastFireTime> self.fireRate) {
            [self normalShoot];
            if (self.doubleFire) {
                [self doubleShoot];
            }
            if (self.shootRocket){
                [self rocketShoot];
            }
            
            self.lastFireTime = currentTime;
             }
    }
    
    NSInteger dropGameObjectsFrequency;
    if (IS_IPAD) {
        dropGameObjectsFrequency = 50;
    }
    else{
        dropGameObjectsFrequency = 20;
    }
   
    if (arc4random_uniform(1000)<=dropGameObjectsFrequency) {
        [self dropGameObjects];
    }
    
    [self checkForColissions];
    self.lastUpdateTime = currentTime;
    
    
}

-(void)endGame{
    [sound stopBackgroundSound];
    [sound stopHomeSound];
    self.counter = 2;
    
    self.gameOver = YES;
    GameOverNode *gameOverNode = [GameOverNode node];
    gameOverNode.position = CGPointMake(self.size.width/2, self.size.height/2);
    [self addChild:gameOverNode];
    
    HUDNode *hudNode = (HUDNode *)[self childNodeWithName:@"hudNode"];
    [hudNode endGame];
    
    
    NSNumber *highScore = [[NSUserDefaults standardUserDefaults] valueForKey:@"highScore"];
   
    if (highScore.integerValue < hudNode.score) {
        [[NSUserDefaults standardUserDefaults] setValue:@(hudNode.score) forKey:@"highScore"];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"saveScore" object:nil];
    
    if (!BOUGHT) {
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0f
                                                      target:self
                                                    selector:@selector(decrementCounter:)
                                                    userInfo:nil
                                                     repeats:YES];

    }
    
    
}

-(void)moveHero:(CGPoint)point byTimeDelta:(NSTimeInterval)timeDelta{
    
    if (self.allowedToTouch) {
        
        CGFloat heroSpeed;
        if (IS_IPAD) {
            heroSpeed = 300;
        }
        else{
            heroSpeed = 220;
        }

    ; //ponts for seconds
    SKNode *hero = [self childNodeWithName:@"hero"];
    CGFloat distanceLeft =  sqrtf(powf(hero.position.x - point.x, 2) + powf(hero.position.y - point.y, 2));
    
    if (distanceLeft > 4) {
        CGFloat distanceToTravel =  timeDelta * heroSpeed;
        CGFloat angle = atan2f(point.y-hero.position.y, point.x-hero.position.x);
        CGFloat yOffSet = distanceToTravel * sin(angle);
        CGFloat xOffSet = distanceToTravel * cos(angle);
        hero.position = CGPointMake(hero.position.x + xOffSet, hero.position.y + yOffSet);
        }
        
    }
    
}

-(void)normalShoot{
    
    if (self.allowedToTouch) {
        SKNode *hero = [self childNodeWithName:@"hero"];
        
        SKSpriteNode *fire = [SKSpriteNode spriteNodeWithImageNamed:@"blueBlaster"];
        fire.name = @"fire";
        fire.size = CGSizeMake(10, 13);
        fire.position = CGPointMake(hero.position.x, hero.position.y + hero.frame.size.height/2);
        [self addChild:fire];
        
        SKAction *move = [SKAction moveByX:0 y:self.size.height + fire.size.height duration:0.5];
        SKAction *remove = [SKAction removeFromParent];
        SKAction *moveAndRemove = [SKAction sequence:@[move, remove]];
        [fire runAction:moveAndRemove];
        
        [self runAction:self.shootSound];
    }
    
  
                          
}

-(void)doubleShoot{
    
    SKNode *hero = [self childNodeWithName:@"hero"];
    
    SKSpriteNode *leftFire = [SKSpriteNode spriteNodeWithImageNamed:@"redBlaster"];
    leftFire.name = @"fire";
    leftFire.size = CGSizeMake(10, 13);
    leftFire.position = CGPointMake(hero.position.x-20, hero.position.y + hero.frame.size.height/2-35);
    [self addChild:leftFire];
    
    SKAction *leftMove = [SKAction moveByX:0 y:self.size.height + leftFire.size.height duration:0.5];
    SKAction *leftRemove = [SKAction removeFromParent];
    SKAction *moveAndRemoveLeft = [SKAction sequence:@[leftMove, leftRemove]];
    [leftFire runAction:moveAndRemoveLeft];
    
    SKSpriteNode *rightFire = [SKSpriteNode spriteNodeWithImageNamed:@"redBlaster"];
    rightFire.name = @"fire";
    rightFire.size = CGSizeMake(10, 13);
    rightFire.position = CGPointMake(hero.position.x+20, hero.position.y + hero.frame.size.height/2-35);
    [self addChild:rightFire];
    
    SKAction *rightMove = [SKAction moveByX:0 y:self.size.height + rightFire.size.height duration:0.5];
    SKAction *rightRemove = [SKAction removeFromParent];
    SKAction *moveAndRemoveRight = [SKAction sequence:@[rightMove, rightRemove]];
    [rightFire runAction:moveAndRemoveRight];
    
}

-(void)rocketShoot{
    
    SKNode *hero = [self childNodeWithName:@"hero"];
    
    SKSpriteNode *leftFire = [SKSpriteNode spriteNodeWithImageNamed:@"rocketBlue"];
    leftFire.name = @"shootRocket";
    leftFire.size = CGSizeMake(15,25);
    leftFire.position = CGPointMake(hero.position.x-20, hero.position.y + hero.frame.size.height/2-35);
    [self addChild:leftFire];
    
    SKAction *leftMove = [SKAction moveByX:0 y:self.size.height + leftFire.size.height duration:0.5];
    SKAction *leftRemove = [SKAction removeFromParent];
    SKAction *moveAndRemoveLeft = [SKAction sequence:@[leftMove, leftRemove]];
    [leftFire runAction:moveAndRemoveLeft];
    
    SKSpriteNode *rightFire = [SKSpriteNode spriteNodeWithImageNamed:@"rocketBlue"];
    rightFire.name = @"shootRocket";
    rightFire.size = CGSizeMake(15, 25);
    rightFire.position = CGPointMake(hero.position.x+20, hero.position.y + hero.frame.size.height/2-35);
    [self addChild:rightFire];
    
    SKAction *rightMove = [SKAction moveByX:0 y:self.size.height + rightFire.size.height duration:0.5];
    SKAction *rightRemove = [SKAction removeFromParent];
    SKAction *moveAndRemoveRight = [SKAction sequence:@[rightMove, rightRemove]];
    [rightFire runAction:moveAndRemoveRight];
    
}

-(void)dropGameObjects{
    
    u_int32_t dice;
    
    if (IS_IPAD) {
        dice = arc4random_uniform(80);
    }
    else{
        dice = arc4random_uniform(100);
    }
    
    if (dice < 8) {
        [self dropPower];
    }
    else if (dice < 10){
        [self dropRocketPower];
    }
    else if (dice < 15){
        [self dropDoubleFire];
    }
    else if (dice < 25){
        [self dropEmenyType1];
    }
    else if (dice < 40){
        [self asteroids];
    }
    else{
        [self dropUFO];
    }
    
}

-(void)dropPower{
    CGFloat powerSize;
    if (IS_IPAD) {
        powerSize =  40;
    }
    else{
        powerSize = 30;
    }
    CGFloat startY = self.size.height + powerSize;
    CGFloat startX = arc4random_uniform(self.size.width-60)+30;
    CGFloat endY = 0 - powerSize;
    
    SKSpriteNode *power = [SKSpriteNode spriteNodeWithImageNamed:@"superShot"];
    power.name = @"power";
    power.size = CGSizeMake(powerSize, powerSize);
    power.position = CGPointMake(startX, startY);
    [self addChild:power];
    
    SKAction *move = [SKAction moveTo:CGPointMake(startX, endY) duration:6];
    SKAction *spin = [SKAction rotateToAngle:-1 duration:1];
    SKAction *remove = [SKAction removeFromParent];
    
    SKAction *spinForever = [SKAction repeatActionForever:spin];
    SKAction *moveAndRemove = [SKAction sequence:@[move, remove]];
    SKAction *allTogether =  [SKAction group:@[spinForever, moveAndRemove]];
    [power runAction:allTogether];
    
    
    
}

-(void)dropRocketPower{
    
    CGFloat powerSize;
    if (IS_IPAD) {
        powerSize =  40;
    }
    else{
        powerSize = 30;
    }
   
    CGFloat startY = self.size.height + powerSize;
    CGFloat startX = arc4random_uniform(self.size.width-60)+30;
    CGFloat endY = 0 - powerSize;
    
    SKSpriteNode *power = [SKSpriteNode spriteNodeWithImageNamed:@"rocketPower"];
    power.name = @"rocketPower";
    power.size = CGSizeMake(powerSize, powerSize);
    power.position = CGPointMake(startX, startY);
    [self addChild:power];
    
    SKAction *move = [SKAction moveTo:CGPointMake(startX, endY) duration:6];
    SKAction *spin = [SKAction rotateToAngle:-1 duration:1];
    SKAction *remove = [SKAction removeFromParent];
    
    SKAction *spinForever = [SKAction repeatActionForever:spin];
    SKAction *moveAndRemove = [SKAction sequence:@[move, remove]];
    SKAction *allTogether =  [SKAction group:@[spinForever, moveAndRemove]];
    [power runAction:allTogether];
    
    
    
}

-(void)dropDoubleFire{
    CGFloat doublepowerSize;
    if (IS_IPAD) {
        doublepowerSize =  40;
    }
    else{
        doublepowerSize = 30;
    }
    
    
    CGFloat startY = self.size.height + doublepowerSize;
    CGFloat startX = arc4random_uniform(self.size.width-60)+30;
    CGFloat endY = 0 - doublepowerSize;
    
    SKSpriteNode *doublepower = [SKSpriteNode spriteNodeWithImageNamed:@"doublepower"];
    doublepower.name = @"doublefire";
    doublepower.size = CGSizeMake(doublepowerSize, doublepowerSize);
    doublepower.position = CGPointMake(startX, startY);
    [self addChild:doublepower];
    
    SKAction *move = [SKAction moveTo:CGPointMake(startX, endY) duration:6];
    SKAction *spin = [SKAction rotateToAngle:-1 duration:1];
    SKAction *remove = [SKAction removeFromParent];
    
    SKAction *spinForever = [SKAction repeatActionForever:spin];
    SKAction *moveAndRemove = [SKAction sequence:@[move, remove]];
    SKAction *allTogether =  [SKAction group:@[spinForever, moveAndRemove]];
    [doublepower runAction:allTogether];
    
}

-(void)dropEmenyType1{
    CGFloat enemySize;
    if (IS_IPAD) {
        enemySize =  50;
    }
    else{
        enemySize = 30;
    }
    
    CGFloat startX = arc4random_uniform(self.size.width -40)+20;
    CGFloat startY = self.size.height + enemySize;
    
    NSInteger shortShip = arc4random_uniform(2);
    SKSpriteNode *enemy;
    
    if (shortShip) {
       enemy = [SKSpriteNode spriteNodeWithImageNamed:@"spaceShip1"];
    }
    else{
        enemy = [SKSpriteNode spriteNodeWithImageNamed:@"spaceShip0"];
    }
    
  
    enemy.name = @"enemy";
    enemy.size = CGSizeMake(enemySize, enemySize *1.84);
    enemy.position = CGPointMake(startX, startY);
    [self addChild:enemy];
    
    int pathNumber = arc4random_uniform(5)+1;
    CGPathRef enemyPath =  [self EnemyMovementPath:pathNumber];
    SKAction *followPath = [SKAction followPath:enemyPath asOffset:YES orientToPath:YES duration:7];
    SKAction *remove = [SKAction removeFromParent];
    SKAction *followAndRemove = [SKAction sequence:@[followPath, remove]];
    [enemy runAction:followAndRemove];
    
    
}

-(void)asteroids{
    CGFloat enemySize;
    if (IS_IPAD) {
        enemySize =  50;
    }
    else{
        enemySize = 30;
    }
    CGFloat startX = arc4random_uniform(self.size.width -40)+20;
    CGFloat startY = self.size.height + enemySize;
    CGFloat endX = arc4random_uniform(self.size.width);
    CGFloat endY = 0 - enemySize;
    
    NSInteger shortAsteroid = arc4random_uniform(4);
    SKSpriteNode *enemy;
    
    switch (shortAsteroid) {
        case 0:
            enemy = [SKSpriteNode spriteNodeWithImageNamed:@"asteroid0"];
            break;
        case 1:
            enemy = [SKSpriteNode spriteNodeWithImageNamed:@"asteroid1"];
            break;
        case 2:
            enemy = [SKSpriteNode spriteNodeWithImageNamed:@"asteroid2"];
            break;
        case 3:
            enemy = [SKSpriteNode spriteNodeWithImageNamed:@"asteroid3"];
            break;
        default:
            break;
    }
    
    
    enemy.name = @"asteroid";
    enemy.size = CGSizeMake(enemySize*3, enemySize *3);
    enemy.position = CGPointMake(startX, startY);
    [self addChild:enemy];
    
    SKAction *move = [SKAction moveTo:CGPointMake(endX, endY) duration:3 + arc4random_uniform(4)];
    SKAction *remove = [SKAction removeFromParent];
    SKAction *moveAndRemove = [SKAction sequence:@[move, remove]];
    
    [enemy runAction:moveAndRemove];

    
}

-(void)dropUFO{
    CGFloat ufoSize;
    if (IS_IPAD) {
        ufoSize =  30;
    }
    else{
        ufoSize = 15;
    }
    ufoSize = ufoSize + arc4random_uniform(30);
    CGFloat maxX = self.size.width;
    CGFloat quarterX = maxX /4;
    CGFloat startX = arc4random_uniform(maxX + (quarterX * 2)) - quarterX;
    CGFloat startY = self.size.height + ufoSize;
    CGFloat endX = arc4random_uniform(maxX);
    CGFloat endY = 0 - ufoSize;
    
    NSInteger  shortEnemy= arc4random_uniform(2);
    SKSpriteNode *ufo;
    NSArray *textures;
    
    if (shortEnemy) {
        ufo = [SKSpriteNode spriteNodeWithImageNamed:@"enemy0"];
        textures = @[[SKTexture textureWithImageNamed:@"enemy0"],
                     [SKTexture textureWithImageNamed:@"enemy1"]];
    }
    else{
        ufo = [SKSpriteNode spriteNodeWithImageNamed:@"enemyUnit0"];
        textures = @[[SKTexture textureWithImageNamed:@"enemyUnit0"],
                     [SKTexture textureWithImageNamed:@"enemyUnit1"]];
    }
    
    SKAction *ufoAnimation = [SKAction animateWithTextures:textures timePerFrame:0.5];
    SKAction *ufoAnimationRepeat = [SKAction repeatActionForever:ufoAnimation];
    [ufo runAction:ufoAnimationRepeat];
    
    ufo.size = CGSizeMake(ufoSize, ufoSize);
    ufo.name = @"enemy";
    ufo.position =  CGPointMake(startX, startY);
    [self addChild:ufo];
    
    SKAction *move = [SKAction moveTo:CGPointMake(endX, endY) duration:3 + arc4random_uniform(4)];
    SKAction *remove = [SKAction removeFromParent];
    SKAction *moveAndRemove = [SKAction sequence:@[move, remove]];
    
    [ufo runAction:moveAndRemove];
    
    
}

-(CGPathRef)EnemyMovementPath:(int)path{
    UIBezierPath *bezierPath = [UIBezierPath bezierPath];
    if (path == 1) {
        
        [bezierPath moveToPoint: CGPointMake(-0.5, 0.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-71.5, -171.5)
                      controlPoint1: CGPointMake(39.5, -109.5)
                      controlPoint2: CGPointMake(-46.5, -121.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(61.5, -373.5)
                      controlPoint1: CGPointMake(-96.5, -221.5)
                      controlPoint2: CGPointMake(123.5, -279.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-71.5, -505.5)
                      controlPoint1: CGPointMake(-0.5, -467.5)
                      controlPoint2: CGPointMake(-59.5, -439.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-0.5, -598.5)
                      controlPoint1: CGPointMake(-83.5, -571.5)
                      controlPoint2: CGPointMake(-0.5, -598.5)];
        
    }else if (path == 2){
        
        [bezierPath moveToPoint: CGPointMake(-2.4, -0.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-78.4, -208.5)
                      controlPoint1: CGPointMake(-82.36, -98.5)
                      controlPoint2: CGPointMake(-106.11, -72.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(51.43, -330.5)
                      controlPoint1: CGPointMake(-50.69, -344.5)
                      controlPoint2: CGPointMake(113.98, -208.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-78.4, -363.5)
                      controlPoint1: CGPointMake(-11.11, -452.5)
                      controlPoint2: CGPointMake(-92.65, -259.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(11.06, -588.5)
                      controlPoint1: CGPointMake(-64.15, -467.5)
                      controlPoint2: CGPointMake(11.06, -588.5)];
        
    }else if (path == 3){
        
        [bezierPath moveToPoint: CGPointMake(1.5, -0.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-24.5, -180.5)
                      controlPoint1: CGPointMake(-4.5, -137.5)
                      controlPoint2: CGPointMake(5.5, -31.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(63.5, -393.5)
                      controlPoint1: CGPointMake(-54.5, -329.5)
                      controlPoint2: CGPointMake(63.5, -309.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-64.5, -587.5)
                      controlPoint1: CGPointMake(63.5, -477.5)
                      controlPoint2: CGPointMake(-64.5, -587.5)];
        
    }else if (path == 4){
        
        [bezierPath moveToPoint: CGPointMake(0.5, -0.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(38.5, -166.5)
                      controlPoint1: CGPointMake(72.5, -91.5)
                      controlPoint2: CGPointMake(76.5, -126.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-40.5, -253.5)
                      controlPoint1: CGPointMake(0.5, -206.5)
                      controlPoint2: CGPointMake(-30.5, -194.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(74.5, -356.5)
                      controlPoint1: CGPointMake(-50.5, -312.5)
                      controlPoint2: CGPointMake(91.5, -272.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-11.5, -458.5)
                      controlPoint1: CGPointMake(57.5, -440.5)
                      controlPoint2: CGPointMake(17.5, -411.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(0.5, -577.5)
                      controlPoint1: CGPointMake(-40.5, -505.5)
                      controlPoint2: CGPointMake(0.5, -577.5)];
    }
    else{
        
        [bezierPath moveToPoint: CGPointMake(-3.5, -0.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(27.5, -162.5)
                      controlPoint1: CGPointMake(18.5, -38.5)
                      controlPoint2: CGPointMake(75.5, -79.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-73.5, -322.5)
                      controlPoint1: CGPointMake(-20.5, -245.5)
                      controlPoint2: CGPointMake(-73.5, -267.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(103.5, -260.5)
                      controlPoint1: CGPointMake(-73.5, -377.5)
                      controlPoint2: CGPointMake(130.5, -312.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-85.5, -240.5)
                      controlPoint1: CGPointMake(76.5, -208.5)
                      controlPoint2: CGPointMake(-68.5, -192.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(-99.5, -418.5)
                      controlPoint1: CGPointMake(-102.5, -288.5)
                      controlPoint2: CGPointMake(-113.5, -371.5)];
        
        [bezierPath addCurveToPoint: CGPointMake(67.5, -601.5)
                      controlPoint1: CGPointMake(-85.5, -465.5)
                      controlPoint2: CGPointMake(67.5, -601.5)];
        
    }
    
    return bezierPath.CGPath;
}

-(void)pauseView
{
    

    self.view.scene.paused = YES;
   
    SKSpriteNode *pauseMenu = [SKSpriteNode spriteNodeWithImageNamed:@"pauseMenu"];
    pauseMenu.name = @"pauseMenu";
    //
    SKSpriteNode *homeButton = [SKSpriteNode spriteNodeWithImageNamed:@"homeButton"];
    homeButton.name = @"homeButton";
    //
    SKSpriteNode *playButton = [SKSpriteNode spriteNodeWithImageNamed:@"playButton"];
    playButton.name = @"playButton";
    
    
    pauseMenu.position = CGPointMake(CGRectGetMidX(self.frame),
                                     CGRectGetMidY(self.frame));
    
    playButton.position = CGPointMake(CGRectGetMidX(pauseMenu.frame),
                                      CGRectGetMidY(pauseMenu.frame)+30);

    
    homeButton.position = CGPointMake(CGRectGetMidX(pauseMenu.frame),
                                      CGRectGetMidY(pauseMenu.frame)-60);

    [self addChild:pauseMenu];
    [self addChild:playButton];
    [self addChild:homeButton];
    self.allowedToTouch = NO;
    
    
}

-(void)playFromPause{
    SKSpriteNode *node1 = (SKSpriteNode*)[self childNodeWithName:@"pauseMenu"];
    SKSpriteNode *node2 = (SKSpriteNode*)[self childNodeWithName:@"homeButton"];
    SKSpriteNode *node3 = (SKSpriteNode*)[self childNodeWithName:@"playButton"];
    
    [node1 removeFromParent];
    [node2 removeFromParent];
    [node3 removeFromParent];
    
    [self setPaused:NO];
    self.allowedToTouch = YES;
}

-(void) showMenu
{
    self.allowedToTouch = YES;
    [self setPaused:NO];
    SKView * skView = (SKView *)self.view;
    
    SKScene * scene = [TitleScene sceneWithSize:skView.bounds.size];
    scene.scaleMode = SKSceneScaleModeAspectFill;
    
    // Present the scene.
    SKTransition *doors = [SKTransition
                           doorsOpenHorizontalWithDuration:1.0];
    [skView presentScene:scene transition:doors];
    
}

- (void)decrementCounter:(NSTimer *)timer {
    self.counter--;
    if (self.counter == 0) {
       [[NSNotificationCenter defaultCenter]postNotificationName:@"gameOver" object:self];
    }
}




@end

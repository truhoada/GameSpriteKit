//
//  SKEmitterNode+Extensions.h
//  Space Fun
//
//  Created by Itamar Sousa Silva on 05/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKEmitterNode (Extensions)

+(SKEmitterNode *)nodeFileWith:(NSString *)fileName;
-(void)dieInDuration:(NSTimeInterval)duration;

@end

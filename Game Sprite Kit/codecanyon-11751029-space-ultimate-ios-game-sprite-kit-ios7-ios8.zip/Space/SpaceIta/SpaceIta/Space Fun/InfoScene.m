//
//  InfoScence.m
//  Space Fun
//
//  Created by Itamar Sousa Silva on 13/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import "InfoScene.h"
#import "TitleScene.h"
#import "Settings.h"
@implementation InfoScene

-(void)didMoveToView:(SKView *)view {
    
    self.backgroundColor = [SKColor blackColor];
    
    SKSpriteNode *banner = [SKSpriteNode spriteNodeWithImageNamed:@"aboutBanner"];
    banner.position = CGPointMake(self.size.width/2, self.size.height-50);
    [self addChild:banner];
    
    SKSpriteNode *bottom = [SKSpriteNode spriteNodeWithImageNamed:@"aboutBottom"];
    bottom.position = CGPointMake(self.size.width/2, 50);
    [self addChild:bottom];
    
    SKSpriteNode *rateButton = [SKSpriteNode spriteNodeWithImageNamed:@"rate"];
    rateButton.position = CGPointMake(self.size.width/2, self.size.height/2+100);
    rateButton.name = @"rateButton";
    [self addChild:rateButton];
    
    SKSpriteNode *contactButton = [SKSpriteNode spriteNodeWithImageNamed:@"contact"];
    contactButton.position = CGPointMake(self.size.width/2, self.size.height/2);
    contactButton.name = @"contactButton";
    [self addChild:contactButton];
    
    SKSpriteNode *homeButton = [SKSpriteNode spriteNodeWithImageNamed:@"backHome"];
    homeButton.position = CGPointMake(self.size.width/2, self.size.height/2-100);
    homeButton.name = @"homeButton";
    [self addChild:homeButton];
    
    
    SKLabelNode *labelCredit = [SKLabelNode labelNodeWithFontNamed:kFontName];
    labelCredit.fontSize = 14;
    labelCredit.fontColor = [SKColor whiteColor];
    labelCredit.text = kCreditApp;
    labelCredit.position = CGPointMake(self.size.width/2, 70);
    [self addChild:labelCredit];
    
    labelCredit.alpha = 0;
    SKAction *wait =  [SKAction waitForDuration:0.5];
    SKAction *appear = [SKAction fadeAlphaTo:1 duration:0.2];
    SKAction *popUp = [SKAction scaleTo:1.1 duration:0.2];
    SKAction *dropDown = [SKAction scaleTo:1 duration:0.2];
    SKAction *pauseAndAppear = [SKAction sequence:@[wait, appear, popUp, dropDown]];
    SKAction *repeatForever = [SKAction repeatActionForever:pauseAndAppear];
    [labelCredit runAction:repeatForever];
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    
    
    for (UITouch *touch in touches)
    {
        
        CGPoint location = [touch locationInNode:self];
        if ( [[self nodeAtPoint:location].name isEqualToString:@"rateButton"] )
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"rate" object:nil];

        }
        if ( [[self nodeAtPoint:location].name isEqualToString:@"contactButton"] )
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"contact" object:nil];
            
        }
        if ( [[self nodeAtPoint:location].name isEqualToString:@"homeButton"] )
        {
            SKView * skView = (SKView *)self.view;
            SKScene * scene = [TitleScene sceneWithSize:skView.bounds.size];
            scene.scaleMode = SKSceneScaleModeAspectFill;
            SKTransition *doors = [SKTransition
                                   doorsOpenHorizontalWithDuration:1.0];
            [skView presentScene:scene transition:doors];
            
        }
        
    }
}


@end

//
//  GameViewController.h
//  Space Fun
//

//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
#import <StoreKit/StoreKit.h>
#import <Accounts/Accounts.h>
#import <MessageUI/MessageUI.h>
#import <GameKit/GameKit.h>
//AdMob
#import "Settings.h"
#import "Sound.h"
#import "IAPHelper.h"
#import "RageIAPHelper.h"
#import "SVProgressHUD.h"
#import <RevMobAds/RevMobAds.h>
#import <RevMobAds/RevMobAdsDelegate.h>
@import GoogleMobileAds;
@class GADBannerView;
@class GADInterstitial;
@interface GameViewController : UIViewController <MFMailComposeViewControllerDelegate,GADInterstitialDelegate, UIAlertViewDelegate, GKGameCenterControllerDelegate, RevMobAdsDelegate>
{
    GADBannerView *bannerView;
     Sound *sound;
    
    
}
@property (nonatomic, strong)RevMobFullscreen *fullscreen;
@property(nonatomic, strong) GADInterstitial *interstitial;
// A flag indicating whether the Game Center features can be used after a user has been authenticated.
@property (nonatomic) BOOL gameCenterEnabled;

// This property stores the default leaderboard's identifier.
@property (nonatomic, strong) NSString *leaderboardIdentifier;

+(void)showRevMobBanner:(bool)closed;
+(void)hideRevMobBanner:(bool)closed;


@end

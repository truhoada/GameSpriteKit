//
//  Stars.m
//  Space Fun
//
//  Created by Itamar Sousa Silva on 05/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import "Stars.h"

@implementation Stars

-(instancetype)init{
    if (self=[super init]) {
        __weak Stars *weakSelf = self;
        SKAction *update = [SKAction runBlock:^{
            if (arc4random_uniform(10)<7) {
                [weakSelf createStars];
            }
        }];
        SKAction *delay = [SKAction waitForDuration:0.01];
        SKAction *updateLoop = [SKAction sequence:@[delay, update]];
        [self runAction:[SKAction repeatActionForever:updateLoop]];
    }
    
    return self;
}

-(void)createStars{
    
    CGFloat randomX = arc4random_uniform(self.scene.size.width);
    CGFloat maximunY = arc4random_uniform(self.scene.size.height);
    CGPoint randomStart = CGPointMake(randomX, maximunY);
    
    SKSpriteNode *star = [SKSpriteNode spriteNodeWithImageNamed:@"star"];
    star.position = randomStart;
    star.size = CGSizeMake(2, 10);
    star.alpha = 0.1 + arc4random_uniform(10)/10.f;
    [self addChild:star];
    
    CGFloat destinationY = 0 - self.scene.size.height - star.size.height;
    CGFloat duration =  0.1 + arc4random_uniform(10)/10.f;
    SKAction *move = [SKAction moveByX:0 y:destinationY duration:duration];
    SKAction *remove = [SKAction removeFromParent];
    [star runAction:[SKAction sequence:@[move, remove]]];
    
}

@end

//
//  Sound.m
//  Space Fun
//
//  Created by Itamar Sousa Silva on 12/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//



#import "Sound.h"
#import "Settings.h"
@implementation Sound

- (void)initSound{
  
    NSBundle *raizApp = [NSBundle mainBundle];
    NSString *pathBG = [raizApp pathForResource:kPlayBackgroundMusic ofType:@"mp3"];
    NSURL *urlBG = [[NSURL alloc] initFileURLWithPath:pathBG];
    audioPlayerBGSound = [[AVAudioPlayer alloc] initWithContentsOfURL:urlBG error:nil];
    audioPlayerBGSound.numberOfLoops = -1;
    audioPlayerBGSound.volume = 0.3;
    [audioPlayerBGSound prepareToPlay];
    
    NSString *pathInitial = [raizApp pathForResource:kHomeBackgroundMusic ofType:@"mp3"];
    NSURL *urlInitial = [[NSURL alloc] initFileURLWithPath:pathInitial];
    audioPlayerHomeSound = [[AVAudioPlayer alloc] initWithContentsOfURL:urlInitial error:nil];
    audioPlayerHomeSound.numberOfLoops = -1;
    audioPlayerHomeSound.volume = 0.3;
    [audioPlayerHomeSound prepareToPlay];
    

}

//
//Play sound methods
//

//Looped sound

- (void)playBackgroundSound {
    
    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"sound"]isEqualToString:@"ON"]) {

        if (audioPlayerBGSound) {
            [audioPlayerBGSound play];
           
        }
        else {
            [self initSound];
            [self playBackgroundSound];
        }
    }
    else {
        [audioPlayerBGSound stop];
    }
}

- (void)startHomeSound {
   if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"sound"]isEqualToString:@"ON"]) {
       
        if (audioPlayerHomeSound) {
            [audioPlayerHomeSound play];
        }
        else {
            [self initSound];
            [self playBackgroundSound];
        }
    }
}

- (void)stopHomeSound {
  if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"sound"]isEqualToString:@"ON"]) {
      if (audioPlayerHomeSound) {
          [audioPlayerHomeSound stop];
      }
      else {
          [self initSound];
          [self playBackgroundSound];
      }
    }
}

- (void)stopBackgroundSound {
    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"sound"]isEqualToString:@"ON"]) {
        if (audioPlayerBGSound) {
            [audioPlayerBGSound stop];
        }
        else {
            [self initSound];
            [self playBackgroundSound];
        }
    
    }
}






@end

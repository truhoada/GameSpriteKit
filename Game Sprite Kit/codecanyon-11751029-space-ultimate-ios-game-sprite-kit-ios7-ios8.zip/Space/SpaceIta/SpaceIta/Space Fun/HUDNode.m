//
//  HUDNode.m
//  Space Fun
//
//  Created by Itamar Sousa Silva on 09/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import "HUDNode.h"
#import "Settings.h"
@implementation HUDNode

-(instancetype)init{
    if (self = [super init]) {
        
        // scoreGroup
        SKNode *scoreGroup = [SKNode node];
        scoreGroup.name = @"scoreGroup";
        
//        SKLabelNode  *scoreTitle = [SKLabelNode labelNodeWithFontNamed:@"AvenirNext-Medium"];
//        scoreTitle.fontSize = 12;
//        scoreTitle.color = [SKColor whiteColor];
//        scoreTitle.horizontalAlignmentMode = SKLabelHorizontalAlignmentModeLeft;
//        scoreTitle.verticalAlignmentMode = SKLabelVerticalAlignmentModeBottom;
//        scoreTitle.text = @"SCORE";
//        scoreTitle.position = CGPointMake(0, 4);
//        [scoreGroup addChild:scoreTitle];
        
        
        SKSpriteNode *lifeInfo = [SKSpriteNode spriteNodeWithImageNamed:@"powerLife"];
        lifeInfo.position = CGPointMake(0, 4);
        [scoreGroup addChild:lifeInfo];
        
        
        SKLabelNode  *lifeValue = [SKLabelNode labelNodeWithFontNamed:kFontHud];
        lifeValue.fontSize = 15;
        lifeValue.fontColor = [UIColor orangeColor];
        lifeValue.horizontalAlignmentMode = SKLabelHorizontalAlignmentModeLeft;
        lifeValue.verticalAlignmentMode = SKLabelVerticalAlignmentModeTop;
        lifeValue.name = @"lifeValue";
        lifeValue.text = @"100%";
        lifeValue.position = CGPointMake(-75, 15);
        [scoreGroup addChild:lifeValue];
        
        
        SKLabelNode  *scoreValue = [SKLabelNode labelNodeWithFontNamed:kFontHud];
        scoreValue.fontSize = 16;
        scoreValue.color = [SKColor whiteColor];
        scoreValue.horizontalAlignmentMode = SKLabelHorizontalAlignmentModeLeft;
        scoreValue.verticalAlignmentMode = SKLabelVerticalAlignmentModeTop;
        scoreValue.name = @"scoreValue";
        scoreValue.text = @"0";
        scoreValue.position = CGPointMake(5, 15);
        [scoreGroup addChild:scoreValue];
        
        [self addChild:scoreGroup];
        
        self.scoreFormatter = [[NSNumberFormatter alloc]init];
        self.scoreFormatter.numberStyle = NSNumberFormatterDecimalStyle;
        
        self.lifeFormatter = [[NSNumberFormatter alloc]init];
        self.lifeFormatter.numberStyle = NSNumberFormatterDecimalStyle;
        
        self.timeFormatter = [[NSNumberFormatter alloc]init];
        self.timeFormatter.numberStyle = NSNumberFormatterDecimalStyle;
        self.timeFormatter.minimumFractionDigits = 1;
        self.timeFormatter.maximumFractionDigits = 1;
        
        // powerGroup
        SKNode *powerGroup = [SKNode node];
        powerGroup.name = @"powerGroup";
        SKSpriteNode *powerInfo = [SKSpriteNode spriteNodeWithImageNamed:@"superShotInf"];
        powerInfo.position = CGPointMake(0, 4);
        [powerGroup addChild:powerInfo];
        [self addChild:powerGroup];
        
        powerGroup.alpha = 0;
        
        SKAction *scaleUp = [SKAction scaleTo:1.3 duration:0.3];
        SKAction *scaleDown = [SKAction scaleTo:1.0 duration:0.3];
        SKAction *pulse = [SKAction sequence:@[scaleUp, scaleDown]];
        SKAction *repeatForever = [SKAction repeatActionForever:pulse];
        [powerInfo runAction:repeatForever];
        
        
        
        // doubleFireGroup
        SKNode *doubleFireGroup = [SKNode node];
        doubleFireGroup.name = @"doubleFireGroup";
        
        SKSpriteNode *doubleFireInfo = [SKSpriteNode spriteNodeWithImageNamed:@"doubleFireInfo"];
        doubleFireInfo.position = CGPointMake(0, 4);
        [doubleFireGroup addChild:doubleFireInfo];
    
        [self addChild:doubleFireGroup];
        
        doubleFireGroup.alpha = 0;
        
        SKAction *scaleDFUp = [SKAction scaleTo:1.3 duration:0.3];
        SKAction *scaleDFDown = [SKAction scaleTo:1.0 duration:0.3];
        SKAction *pulseDF = [SKAction sequence:@[scaleDFUp, scaleDFDown]];
        SKAction *repeatForeverDF = [SKAction repeatActionForever:pulseDF];
        [doubleFireInfo runAction:repeatForeverDF];
        
        
        //rocket
        SKNode *rocketPowerGroup = [SKNode node];
        rocketPowerGroup.name = @"rocketPowerGroup";
        SKSpriteNode *info = [SKSpriteNode spriteNodeWithImageNamed:@"powerRocketInfo"];
        info.position = CGPointMake(0, 4);
        [rocketPowerGroup addChild:info];
        [self addChild:rocketPowerGroup];

        rocketPowerGroup.alpha = 0;
        
        SKAction *scaleUpRP = [SKAction scaleTo:1.3 duration:0.3];
        SKAction *scaleDownRP = [SKAction scaleTo:1.0 duration:0.3];
        SKAction *pulseRP = [SKAction sequence:@[scaleUpRP, scaleDownRP]];
        SKAction *repeatForeverRP = [SKAction repeatActionForever:pulseRP];
        [info runAction:repeatForeverRP];
        
    }
    
    return self;
}

-(void)addPoints:(NSInteger)points{
    self.score +=points;
    SKLabelNode *scoreValue = (SKLabelNode *)[self childNodeWithName:@"scoreGroup/scoreValue"];
    scoreValue.text = [NSString stringWithFormat:@"%@",[self.scoreFormatter stringFromNumber:@(self.score)]];
    
    SKAction *scaleUP = [SKAction scaleTo:1.3 duration:0.2];
    SKAction *scaleDown = [SKAction scaleTo:1.1 duration:0.7];
    SKAction *scalleALL = [SKAction sequence:@[scaleUP, scaleDown]];
    [scoreValue runAction:scalleALL];
}
//
-(void)updateLife:(NSInteger)points{
    self.life = points;
    SKLabelNode *lifeValue = (SKLabelNode *)[self childNodeWithName:@"scoreGroup/lifeValue"];
    lifeValue.text = [NSString stringWithFormat:@"%@%%",[self.lifeFormatter stringFromNumber:@(self.life)]];
    
    SKAction *scaleUP = [SKAction scaleTo:1.3 duration:0.2];
    SKAction *scaleDown = [SKAction scaleTo:1.1 duration:0.7];
    SKAction *scalleALL = [SKAction sequence:@[scaleUP, scaleDown]];
    [lifeValue runAction:scalleALL];
}

-(void)layoutControls{
    CGSize sceneSize = self.scene.size;
    CGSize groupSize = CGSizeZero;
    
    SKNode *scoreGroup = [self childNodeWithName:@"scoreGroup"];
    groupSize = [scoreGroup calculateAccumulatedFrame].size;
    scoreGroup.position = CGPointMake(100-sceneSize.width/2, sceneSize.height/2-groupSize.height+40);
    
    SKNode *powerGroup = [self childNodeWithName:@"powerGroup"];
    groupSize = [scoreGroup calculateAccumulatedFrame].size;
    powerGroup.position = CGPointMake(0, sceneSize.height/2-groupSize.height-10);
    
    
    SKNode *doubleFireGroup = [self childNodeWithName:@"doubleFireGroup"];
    groupSize = [scoreGroup calculateAccumulatedFrame].size;
    doubleFireGroup.position = CGPointMake(0, (sceneSize.height/2-groupSize.height)-45);
    
    SKNode *rocketPowerGroup = [self childNodeWithName:@"rocketPowerGroup"];
    groupSize = [scoreGroup calculateAccumulatedFrame].size;
    rocketPowerGroup.position = CGPointMake(0, (sceneSize.height/2-groupSize.height)-80);
    
}

-(void)showPowerTime:(NSTimeInterval)time{
    
    SKNode *powerGroup = [self childNodeWithName:@"powerGroup"];
    [powerGroup removeActionForKey:@"showPowerTime"];
    SKAction *block = [SKAction runBlock:^{
        
    }];
    
    SKAction *blockPause = [SKAction waitForDuration:0.05];
    SKAction *countDownSequence = [SKAction sequence:@[block, blockPause]];
    SKAction *countDownForever = [SKAction repeatActionForever:countDownSequence];
    
    SKAction *fadIn = [SKAction fadeAlphaTo:1 duration:0.3];
    SKAction *wait = [SKAction waitForDuration:time];
    SKAction *fadeOut = [SKAction fadeAlphaTo:0 duration:0.2];
    SKAction *stopAction = [SKAction runBlock:^{
        [powerGroup removeActionForKey:@"showPowerTime"];
        
    }];
    //
    SKAction *visuals = [SKAction sequence:@[fadIn, wait, fadeOut, stopAction]];
    [powerGroup runAction:[SKAction group:@[countDownForever,visuals]]withKey:@"showPowerTime"];

}

-(void)showDoubleFireTime:(NSTimeInterval)time{
    SKNode *doubleFireGroup = [self childNodeWithName:@"doubleFireGroup"];
    [doubleFireGroup removeActionForKey:@"showDoubleFireTime"];
    SKAction *block = [SKAction runBlock:^{
        
    }];
    
    SKAction *blockPause = [SKAction waitForDuration:0.05];
    SKAction *countDownSequence = [SKAction sequence:@[block, blockPause]];
    SKAction *countDownForever = [SKAction repeatActionForever:countDownSequence];
    
    SKAction *fadIn = [SKAction fadeAlphaTo:1 duration:0.3];
    SKAction *wait = [SKAction waitForDuration:time];
    SKAction *fadeOut = [SKAction fadeAlphaTo:0 duration:0.2];
    SKAction *stopAction = [SKAction runBlock:^{
        [doubleFireGroup removeActionForKey:@"showDoubleFireTime"];
        
    }];
    //
    SKAction *visuals = [SKAction sequence:@[fadIn, wait, fadeOut, stopAction]];
    [doubleFireGroup runAction:[SKAction group:@[countDownForever,visuals]]withKey:@"showDoubleFireTime"];

    
}

-(void)showRocketPowerTime:(NSTimeInterval)time{
    
    SKNode *rocketPowerGroup = [self childNodeWithName:@"rocketPowerGroup"];
    [rocketPowerGroup removeActionForKey:@"showRocketPowerTime"];
    SKAction *block = [SKAction runBlock:^{
        
    }];
    
    SKAction *blockPause = [SKAction waitForDuration:0.05];
    SKAction *countDownSequence = [SKAction sequence:@[block, blockPause]];
    SKAction *countDownForever = [SKAction repeatActionForever:countDownSequence];
    
    SKAction *fadIn = [SKAction fadeAlphaTo:1 duration:0.3];
    SKAction *wait = [SKAction waitForDuration:time];
    SKAction *fadeOut = [SKAction fadeAlphaTo:0 duration:0.2];
    SKAction *stopAction = [SKAction runBlock:^{
        [rocketPowerGroup removeActionForKey:@"showRocketPowerTime"];
        
    }];
    //
    SKAction *visuals = [SKAction sequence:@[fadIn, wait, fadeOut, stopAction]];
    [rocketPowerGroup runAction:[SKAction group:@[countDownForever,visuals]]withKey:@"showRocketPowerTime"];
    
}




-(void)startGame{
    NSTimeInterval startTime = [NSDate timeIntervalSinceReferenceDate];
    __weak HUDNode *weakSelf = self;
    SKAction *update = [SKAction runBlock:^{
        NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
        NSTimeInterval elapsed = now - startTime;
        weakSelf.elapsedTime = elapsed;
    }];
    
    SKAction *delay = [SKAction waitForDuration:0.05];
    SKAction *updateAndDelay = [SKAction sequence:@[update, delay]];
    SKAction *timer = [SKAction repeatActionForever:updateAndDelay];
    [self runAction:timer withKey:@"elapsedGameTime"];
}

-(void)endGame{
    SKNode *powerGroup = [self childNodeWithName:@"powerGroup"];
    [powerGroup removeActionForKey:@"showPowerTime"];
    SKAction *feadOut = [SKAction fadeAlphaTo:0 duration:0.3];
    [powerGroup runAction:feadOut];
    //
    SKNode *doubleFireGroup = [self childNodeWithName:@"doubleFireGroup"];
    [doubleFireGroup removeActionForKey:@"showDoubleFireTime"];
    SKAction *feadOutDF = [SKAction fadeAlphaTo:0 duration:0.3];
    [doubleFireGroup runAction:feadOutDF];
    //
    SKNode *rocketPowerGroup = [self childNodeWithName:@"rocketPowerGroup"];
    [rocketPowerGroup removeActionForKey:@"showRocketPowerTime"];
    SKAction *feadOutRP = [SKAction fadeAlphaTo:0 duration:0.3];
    [doubleFireGroup runAction:feadOutRP];
    
    
}


@end

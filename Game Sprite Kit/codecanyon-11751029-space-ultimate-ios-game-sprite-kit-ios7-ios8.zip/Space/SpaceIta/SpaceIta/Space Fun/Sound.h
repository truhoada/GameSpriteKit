//
//  Sound.h
//  Space Fun
//
//  Created by Itamar Sousa Silva on 12/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//



#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface Sound : NSObject{
    AVAudioPlayer *audioPlayerBGSound;
    AVAudioPlayer *audioPlayerHomeSound;
    
}



- (void)initSound;

//Play sound methods
- (void)playBackgroundSound;
- (void)startHomeSound;
- (void)stopHomeSound;
- (void)stopBackgroundSound;

//




@end

//
//  HUDNode.h
//  Space Fun
//
//  Created by Itamar Sousa Silva on 09/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface HUDNode : SKNode

-(void)addPoints:(NSInteger)points;
-(void)updateLife:(NSInteger)points;
-(void)startGame;
-(void)endGame;

-(void)showPowerTime:(NSTimeInterval)time;
-(void)showDoubleFireTime:(NSTimeInterval)time;
-(void)showRocketPowerTime:(NSTimeInterval)time;

-(void)layoutControls;

@property (nonatomic) NSTimeInterval elapsedTime;
@property (nonatomic) NSInteger score;
@property (nonatomic) NSInteger life;

@property (strong, nonatomic) NSNumberFormatter *timeFormatter;
@property (strong, nonatomic) NSNumberFormatter *scoreFormatter;
@property (strong, nonatomic) NSNumberFormatter *lifeFormatter;


@end

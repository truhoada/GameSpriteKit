//
//  Settings.h
//  Space Fun
//
//  Created by Itamar Sousa Silva on 12/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//


//Ads setting

#define AdMobID @"ca-app-pub-9426154991177043/9854595614"
#define AdMobIN @"ca-app-pub-9426154991177043/2331328817"

#define RevMobID @"5581a10e5f84ea5f66bee8d8"

#define GOOGLE_ADS 0
/*Google ADS
 1 - show
 0 - do not show
 */

#define REVMOD_ADS 1
/*REVMOB ADS
 1 - show
 0 - do not show
 */

//inapp
#define INAPP @"IN0001"

#define BOUGHT [[NSUserDefaults standardUserDefaults]boolForKey:@"bought"] 

//Flury Analytics
#define FLURRY_KEY @"D24XZ36FZ6XNS458JTXC"


#define RATEUS_LINK @"https://itunes.apple.com/us/app/space-ultimate-free/id976963718?l=pt&ls=1&mt=8"

//App font
static NSString *const kFontName = @"Neuropol";

//HUD font
static NSString *const kFontHud = @"Planer";

//Leaderboard ID
static NSString *const kGamecenterLeaderboardID = @"";

//Titel App
static NSString *const kTitleApp = @"Space Ultimate";

//Instruction App
static NSString *const kInstructionApp = @"Tap to start the game";

// Label credit App
static NSString *const kCreditApp = @"by Itamar Silva";

//text share message
static NSString *const kTextShareMessage = @"I'm playing the Space Ultimate for iOS\n Best Score:%@\nDownload:http://goo.gl/56w3QT";


//Twitter error message
static NSString *const kTextErrorShare = @"You can't send";

//email contact message
static NSString *const kEmailContact = @"itamar.apps@gmail.com";

//text email body
static NSString *const kTextEmailBody = @"Write any thing";


//Rate app link
static NSString *const kRateAppID = @"id976963718";

//Background music
static NSString *const kHomeBackgroundMusic = @"home";

//Play background music
static NSString *const kPlayBackgroundMusic = @"battle";

//shoot sound
static NSString *const kShootSound = @"shot.mp3";

//enemy explosion sound
static NSString *const kEnemyExplosionSound = @"explosion.mp3";

//hero explosion sound
static NSString *const kHeroExplosionSound = @"explosionbig.mp3";





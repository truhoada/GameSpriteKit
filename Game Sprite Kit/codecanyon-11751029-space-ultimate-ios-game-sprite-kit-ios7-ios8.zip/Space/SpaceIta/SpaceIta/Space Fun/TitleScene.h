//
//  GameScene.h
//  Space Fun
//

//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
#import <Social/Social.h>
#import "Sound.h"


@interface TitleScene : SKScene <UIAlertViewDelegate> {
 
    
    BOOL soundOn;
}
@property (nonatomic) SKSpriteNode *adsButton;
@property (nonatomic) SKSpriteNode *soundButton;
@property (nonatomic) Sound *sound;
@end

//
//  GameStartNode.m
//  Space Fun
//
//  Created by Itamar Sousa Silva on 05/03/15.
//  Copyright (c) 2015 com.itamarSilvaDeveloper. All rights reserved.
//

#import "GameStartNode.h"
#import "Settings.h"
@implementation GameStartNode

-(instancetype)init{
    if (self=[super init]) {
        
        SKLabelNode *label = [SKLabelNode labelNodeWithFontNamed:kFontName];
        label.fontSize = 36;
        label.fontColor = [SKColor whiteColor];
        label.text = kTitleApp;
        [self addChild:label];
        
        label.alpha = 0;
        label.xScale = 0.2;
        label.yScale = 0.2;
        SKAction *fadeIn = [SKAction fadeAlphaTo:1 duration:2];
        SKAction *scaleIn = [SKAction scaleTo:1 duration:2];
        SKAction *fadeAndScale = [SKAction group:@[fadeIn, scaleIn]];
        [label runAction:fadeAndScale];
        
        SKLabelNode *labelInstruction = [SKLabelNode labelNodeWithFontNamed:kFontName];
        labelInstruction.fontSize = 14;
        labelInstruction.fontColor = [SKColor colorWithRed:0 green:247 blue:253 alpha:1];
        labelInstruction.text = kInstructionApp;
        labelInstruction.position = CGPointMake(0, -45);
        [self addChild:labelInstruction];
        
        labelInstruction.alpha = 0;
        SKAction *wait =  [SKAction waitForDuration:2];
        SKAction *appear = [SKAction fadeAlphaTo:1 duration:0.2];
        SKAction *popUp = [SKAction scaleTo:1.1 duration:0.2];
        SKAction *dropDown = [SKAction scaleTo:1 duration:0.2];
        SKAction *pauseAndAppear = [SKAction sequence:@[wait, appear, popUp, dropDown]];
        SKAction *repeatForever = [SKAction repeatActionForever:pauseAndAppear];
        [labelInstruction runAction:repeatForever];
        
        
    }
    
    
    return self;
}

@end
